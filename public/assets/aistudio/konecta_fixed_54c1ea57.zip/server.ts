import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

dotenv.config();

const app = express();
app.use(express.json({ verify: (req: any, _res, buf) => { req.rawBody = buf; } }));
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3000;
const SUPABASE_URL = process.env.VITE_SUPABASE_URL || 'https://rrczdshxyuamtomuswmv.supabase.co';
const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJyY3pkc2h4eXVhbXRvbXVzd212Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMzNjkzODEsImV4cCI6MjEwODk0NTM4MX0.kNAHRVs4J5Z43ehGfutE6C9J0DmFzleoOxS2bi3ItCw';

// O servidor precisa da service_role para gravar pedidos de verificação e processar webhooks
// (as políticas RLS só permitem escrita a utilizadores autenticados). NUNCA expor esta chave no frontend.
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
if (!SUPABASE_SERVICE_ROLE_KEY) {
  console.warn('[verificação] SUPABASE_SERVICE_ROLE_KEY em falta: gravações no Supabase vão falhar por RLS.');
}
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY || SUPABASE_ANON_KEY, {
  auth: { persistSession: false, autoRefreshToken: false }
});

// Didit Configuration
const DIDIT_APP_ID = process.env.DIDIT_APP_ID || 'fd452321-eb1f-4413-b328-13e4c26a7571';
const DIDIT_API_KEY = process.env.DIDIT_API_KEY || '';
const DIDIT_BASE_URL = process.env.DIDIT_BASE_URL || 'https://verification.didit.me';
const DIDIT_BI_WORKFLOW_ID = process.env.DIDIT_WORKFLOW_BI_ID || '2ff17dd6-e06d-4176-b0d0-36933fd33594';
const DIDIT_BI_LINK = 'https://verify.didit.me/u/L_F91uBtQXaw0DaTP9M1lA';
const DIDIT_EMPRESA_WORKFLOW_ID = process.env.DIDIT_WORKFLOW_EMPRESA_ID || '6e57bec1-d247-4af6-88be-155edef5cac0';
const DIDIT_EMPRESA_LINK = 'https://verify.didit.me/u/ble-wdJHSvaIvhVe3vXKwA';
const DIDIT_WEBHOOK_SECRET = process.env.DIDIT_WEBHOOK_SECRET || '';
const APP_BASE_URL = process.env.APP_BASE_URL || 'http://localhost:3000';

// Webhook idempotency & active sessions cache
const processedWebhooks = new Set<string>();
const activeSessions = new Map<string, any>();

// Cria uma sessão REAL na Didit (API v3). Lança erro se falhar: nunca inventamos links.
async function createDiditSessionViaApi(workflowId: string, vendorData: string, callbackUrl: string) {
  if (!DIDIT_API_KEY) {
    throw new Error('DIDIT_API_KEY não configurada no servidor');
  }
  const response = await fetch(`${DIDIT_BASE_URL}/v3/session/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': DIDIT_API_KEY },
    body: JSON.stringify({
      workflow_id: workflowId,
      vendor_data: vendorData,
      callback: callbackUrl
    })
  });
  const text = await response.text();
  if (!response.ok) {
    console.error(`Didit ${response.status}: ${text.slice(0, 500)}`);
    throw new Error(`Didit recusou a criação da sessão (HTTP ${response.status})`);
  }
  const data = JSON.parse(text);
  const sessionId = data.session_id || data.id;
  const url = data.url || data.verification_url;
  if (!sessionId || !url) {
    throw new Error('Resposta da Didit sem session_id/url');
  }
  return { sessionId: sessionId as string, url: url as string };
}

// -------------------------------------------------------------
// 1. PUBLIC DIDIT CONFIG
// -------------------------------------------------------------
app.get('/api/didit/config', (req, res) => {
  res.json({
    appId: DIDIT_APP_ID,
    workflows: {
      individual: { id: DIDIT_BI_WORKFLOW_ID, link: DIDIT_BI_LINK, priceKz: 5000 },
      organization: { id: DIDIT_EMPRESA_WORKFLOW_ID, link: DIDIT_EMPRESA_LINK, priceKz: 10000 }
    }
  });
});

// -------------------------------------------------------------
// 2. START BI VERIFICATION SESSION
// Route: POST /api/verification/bi/start
// -------------------------------------------------------------
app.post('/api/verification/bi/start', async (req, res) => {
  try {
    const { userId, fullName, biNumber, targetId: clientTargetId } = req.body;
    const targetId = clientTargetId || userId;

    if (!targetId) {
      return res.status(400).json({ error: 'Identificador de utilizador ou perfil é obrigatório' });
    }

    const rawSessionUuid = crypto.randomUUID();
    const priceKz = 5000;
    const callbackUrl = `${APP_BASE_URL}/verification-return`;

    let apiResult: { sessionId: string; url: string };
    try {
      apiResult = await createDiditSessionViaApi(DIDIT_BI_WORKFLOW_ID, targetId, callbackUrl);
    } catch (e: any) {
      console.error('Falha ao criar sessão Didit:', e);
      return res.status(502).json({ error: 'Não foi possível criar a sessão de verificação. Tente novamente mais tarde.' });
    }
    const sessionId = apiResult.sessionId;
    const verificationUrl = apiResult.url;

    const evidenceMeta = {
      didit_session_id: sessionId,
      session_uuid: rawSessionUuid,
      workflow_id: DIDIT_BI_WORKFLOW_ID,
      verification_url: verificationUrl,
      full_name: fullName || '',
      bi_number: biNumber || '',
      price_kz: priceKz,
      payment_status: 'payment_pending',
      didit_status: 'pending',
      created_at: new Date().toISOString()
    };

    let requestId = rawSessionUuid;

    // Check for existing pending/payment_pending request
    const { data: existing } = await supabase
      .from('profile_verification_requests')
      .select('id')
      .eq('user_id', targetId)
      .in('status', ['payment_pending', 'pending'])
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (existing?.id) {
      requestId = existing.id;
      await supabase
        .from('profile_verification_requests')
        .update({
          status: 'payment_pending',
          evidence_url: JSON.stringify(evidenceMeta)
        })
        .eq('id', existing.id);
    } else {
      const { data: inserted, error: insertError } = await supabase
        .from('profile_verification_requests')
        .insert({
          user_id: targetId,
          status: 'payment_pending',
          explanation: fullName || 'Membro Konecta',
          price_amount: priceKz,
          currency: 'AOA',
          duration_days: 30,
          evidence_url: JSON.stringify(evidenceMeta)
        })
        .select('id')
        .maybeSingle();

      if (insertError) {
        console.error('Erro ao gravar pedido de verificação:', insertError);
        return res.status(500).json({ error: 'Não foi possível registar o pedido de verificação.' });
      }

      if (inserted?.id) {
        requestId = inserted.id;
      }
    }

    const sessionPayload = {
      sessionId,
      requestId,
      targetType: 'profile',
      targetId,
      workflowId: DIDIT_BI_WORKFLOW_ID,
      verificationUrl,
      priceKz,
      status: 'payment_pending',
      paymentStatus: 'payment_pending',
      diditStatus: 'pending',
      createdAt: new Date().toISOString()
    };
    activeSessions.set(sessionId, sessionPayload);
    activeSessions.set(requestId, sessionPayload);

    return res.json({
      success: true,
      sessionId,
      workflowId: DIDIT_BI_WORKFLOW_ID,
      verificationUrl,
      priceKz,
      status: 'payment_pending',
      requestId
    });
  } catch (err: any) {
    console.error('Error starting BI verification:', err);
    return res.status(500).json({ error: err.message || 'Erro ao iniciar verificação de BI' });
  }
});

// -------------------------------------------------------------
// 3. START COMPANY VERIFICATION SESSION
// Route: POST /api/verification/company/start
// -------------------------------------------------------------
app.post('/api/verification/company/start', async (req, res) => {
  try {
    const { userId, organizationId, companyName, nif } = req.body;
    const targetId = organizationId;

    if (!targetId || !userId) {
      return res.status(400).json({ error: 'Identificador da empresa e do requerente são obrigatórios' });
    }

    const rawSessionUuid = crypto.randomUUID();
    const priceKz = 10000;
    const callbackUrl = `${APP_BASE_URL}/verification-return`;

    let apiResult: { sessionId: string; url: string };
    try {
      apiResult = await createDiditSessionViaApi(DIDIT_EMPRESA_WORKFLOW_ID, targetId, callbackUrl);
    } catch (e: any) {
      console.error('Falha ao criar sessão Didit:', e);
      return res.status(502).json({ error: 'Não foi possível criar a sessão de verificação. Tente novamente mais tarde.' });
    }
    const sessionId = apiResult.sessionId;
    const verificationUrl = apiResult.url;

    const evidenceMeta = {
      didit_session_id: sessionId,
      session_uuid: rawSessionUuid,
      workflow_id: DIDIT_EMPRESA_WORKFLOW_ID,
      verification_url: verificationUrl,
      company_name: companyName || '',
      nif: nif || '',
      price_kz: priceKz,
      payment_status: 'payment_pending',
      didit_status: 'pending',
      created_at: new Date().toISOString()
    };

    let requestId = rawSessionUuid;

    const { data: existing } = await supabase
      .from('organization_verification_requests')
      .select('id')
      .eq('organization_id', targetId)
      .in('status', ['payment_pending', 'pending'])
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (existing?.id) {
      requestId = existing.id;
      await supabase
        .from('organization_verification_requests')
        .update({
          status: 'payment_pending',
          evidence_url: JSON.stringify(evidenceMeta)
        })
        .eq('id', existing.id);
    } else {
      const { data: inserted, error: insertError } = await supabase
        .from('organization_verification_requests')
        .insert({
          organization_id: targetId,
          requested_by: userId,
          status: 'payment_pending',
          evidence_url: JSON.stringify(evidenceMeta)
        })
        .select('id')
        .maybeSingle();

      if (insertError) {
        console.error('Erro ao gravar pedido de verificação:', insertError);
        return res.status(500).json({ error: 'Não foi possível registar o pedido de verificação.' });
      }

      if (inserted?.id) {
        requestId = inserted.id;
      }
    }

    const sessionPayload = {
      sessionId,
      requestId,
      targetType: 'organization',
      targetId,
      workflowId: DIDIT_EMPRESA_WORKFLOW_ID,
      verificationUrl,
      priceKz,
      status: 'payment_pending',
      paymentStatus: 'payment_pending',
      diditStatus: 'pending',
      createdAt: new Date().toISOString()
    };
    activeSessions.set(sessionId, sessionPayload);
    activeSessions.set(requestId, sessionPayload);

    return res.json({
      success: true,
      sessionId,
      workflowId: DIDIT_EMPRESA_WORKFLOW_ID,
      verificationUrl,
      priceKz,
      status: 'payment_pending',
      requestId
    });
  } catch (err: any) {
    console.error('Error starting company verification:', err);
    return res.status(500).json({ error: err.message || 'Erro ao iniciar verificação empresarial' });
  }
});

// Alias endpoint for create-session to support d1Client calls
app.post('/api/didit/create-session', async (req, res) => {
  const { targetType } = req.body;
  if (targetType === 'organization') {
    return app._router.handle({ ...req, url: '/api/verification/company/start' }, res);
  }
  return app._router.handle({ ...req, url: '/api/verification/bi/start' }, res);
});

// -------------------------------------------------------------
// 4. CONFIRM PAYMENT FOR VERIFICATION REQUEST
// Route: POST /api/verification/confirm-payment
// -------------------------------------------------------------
app.post(['/api/verification/confirm-payment', '/api/didit/confirm-payment'], async (req, res) => {
  try {
    const { requestId, targetType, paymentMethod, phoneNumber } = req.body;
    const table = targetType === 'organization' ? 'organization_verification_requests' : 'profile_verification_requests';
    const now = new Date().toISOString();

    let cleanUuid = (requestId || '').trim().replace(/^didit_sess_/, '');
    const isValidUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cleanUuid);

    let currentReq: any = null;
    if (isValidUuid) {
      const { data } = await supabase.from(table).select('*').eq('id', cleanUuid).maybeSingle();
      currentReq = data;
    }

    let meta: any = {};
    try { meta = JSON.parse(currentReq?.evidence_url || '{}'); } catch {}

    meta.payment_method = paymentMethod || 'mc_express';
    meta.payment_phone = phoneNumber || '';
    meta.payment_status = 'paid';
    meta.paid_at = now;

    const isDiditApproved = meta.didit_status === 'approved' || meta.didit_decision === 'Approved';

    // If Didit is already approved AND payment is now confirmed, activate badge!
    let nextStatus = 'verification_pending';
    if (isDiditApproved) {
      nextStatus = 'approved';
      const validUntil = new Date(Date.now() + 30 * 86400000).toISOString();
      if (targetType === 'profile' && currentReq?.user_id) {
        await supabase.from('profiles').update({
          is_verified: true,
          verified_at: now,
          verified_until: validUntil,
          updated_at: now
        }).eq('user_id', currentReq.user_id);
      } else if (targetType === 'organization' && currentReq?.organization_id) {
        await supabase.from('organizations').update({
          verification_status: 'verified',
          verified_at: now,
          verified_until: validUntil,
          updated_at: now
        }).eq('id', currentReq.organization_id);
      }
    }

    if (currentReq?.id) {
      await supabase.from(table).update({
        status: nextStatus,
        evidence_url: JSON.stringify(meta)
      }).eq('id', currentReq.id);
    }

    return res.json({
      success: true,
      status: nextStatus,
      requestId: currentReq?.id || cleanUuid,
      paymentConfirmed: true
    });
  } catch (err: any) {
    console.error('Error confirming payment:', err);
    return res.status(500).json({ error: err.message || 'Erro ao confirmar pagamento' });
  }
});

// -------------------------------------------------------------
// 5. WEBHOOK RECEIVER & DIDIT RESULT PROCESSING
// Route: POST /api/verification/didit-webhook & POST /api/didit/webhook
// -------------------------------------------------------------
app.post(['/api/verification/didit-webhook', '/api/didit/webhook'], async (req, res) => {
  try {
    // Verificação de assinatura (obrigatória quando DIDIT_WEBHOOK_SECRET está definido)
    if (DIDIT_WEBHOOK_SECRET) {
      const raw: Buffer | undefined = (req as any).rawBody;
      const sigHeader = String(req.headers['x-signature-v2'] || req.headers['x-signature'] || '');
      const simpleHeader = String(req.headers['x-signature-simple'] || '');
      const ts = String(req.headers['x-timestamp'] || '');
      const hmac = (data: string | Buffer) => crypto.createHmac('sha256', DIDIT_WEBHOOK_SECRET).update(data).digest('hex');
      const safeEq = (x: string, y: string) => x.length === y.length && x.length > 0 && crypto.timingSafeEqual(Buffer.from(x), Buffer.from(y));
      const canonical = (v: any): any => Array.isArray(v) ? v.map(canonical)
        : v && typeof v === 'object' ? Object.keys(v).sort().reduce((o: any, k) => (o[k] = canonical(v[k]), o), {}) : v;
      const b = req.body || {};
      const ok =
        (raw && safeEq(sigHeader, hmac(raw))) ||
        safeEq(sigHeader, hmac(JSON.stringify(canonical(b)))) ||
        safeEq(simpleHeader, hmac(`${ts}:${b.session_id}:${b.status}:${b.webhook_type}`));
      if (!ok) {
        console.warn('Didit webhook: assinatura inválida');
        return res.status(401).json({ error: 'Assinatura inválida' });
      }
      if (ts && Math.abs(Date.now() / 1000 - Number(ts)) > 300) {
        return res.status(401).json({ error: 'Timestamp fora do intervalo permitido' });
      }
    }

    const event = req.body || {};
    const sessionId = event.session_id || event.sessionId || event.id || event.data?.session_id;
    const rawDecision = event.decision || event.status || event.data?.decision || event.data?.status || 'InReview';
    const vendorData = event.vendor_data || event.vendorData || event.data?.vendor_data;

    const eventKey = `${sessionId}_${rawDecision}`;
    if (processedWebhooks.has(eventKey)) {
      return res.json({ success: true, duplicate: true, message: 'Evento já processado' });
    }
    processedWebhooks.add(eventKey);

    // Map Didit decision to platform status
    let mappedStatus: 'approved' | 'rejected' | 'in_review' | 'subscription_expired' = 'in_review';
    if (['Approved', 'approved', 'allow'].includes(rawDecision)) {
      mappedStatus = 'approved';
    } else if (['Rejected', 'rejected', 'Declined', 'declined', 'block'].includes(rawDecision)) {
      mappedStatus = 'rejected';
    } else if (['Expired', 'expired'].includes(rawDecision)) {
      mappedStatus = 'subscription_expired';
    }

    const now = new Date();
    const validUntil = new Date(now.getTime() + 30 * 86400000).toISOString();

    // Check profile request matching session_id or user vendorData
    let profileReq: any = null;
    let orgReq: any = null;

    if (sessionId) {
      const { data: pData } = await supabase
        .from('profile_verification_requests')
        .select('*')
        .like('evidence_url', `%${sessionId}%`)
        .maybeSingle();
      profileReq = pData;

      const { data: oData } = await supabase
        .from('organization_verification_requests')
        .select('*')
        .like('evidence_url', `%${sessionId}%`)
        .maybeSingle();
      orgReq = oData;
    }

    if (!profileReq && vendorData) {
      const { data: pData } = await supabase
        .from('profile_verification_requests')
        .select('*')
        .eq('user_id', vendorData)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      profileReq = pData;
    }

    if (!orgReq && vendorData) {
      const { data: oData } = await supabase
        .from('organization_verification_requests')
        .select('*')
        .eq('organization_id', vendorData)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      orgReq = oData;
    }

    // Process Profile Request
    if (profileReq) {
      let meta: any = {};
      try { meta = JSON.parse(profileReq.evidence_url || '{}'); } catch {}

      meta.didit_decision = rawDecision;
      meta.didit_status = mappedStatus;
      meta.webhook_received_at = now.toISOString();

      const isPaid = meta.payment_status === 'paid' || profileReq.status === 'verification_pending' || profileReq.status === 'approved';

      // CRITICAL: Badge is ONLY granted when BOTH Didit approves AND payment is confirmed!
      if (mappedStatus === 'approved' && isPaid) {
        await supabase.from('profile_verification_requests').update({
          status: 'approved',
          reviewed_at: now.toISOString(),
          evidence_url: JSON.stringify(meta)
        }).eq('id', profileReq.id);

        await supabase.from('profiles').update({
          is_verified: true,
          verified_at: now.toISOString(),
          verified_until: validUntil,
          updated_at: now.toISOString()
        }).eq('user_id', profileReq.user_id);
      } else {
        // Not approved or payment pending
        const targetReqStatus = mappedStatus === 'approved' ? 'verification_pending' : mappedStatus;
        await supabase.from('profile_verification_requests').update({
          status: targetReqStatus,
          reviewed_at: now.toISOString(),
          evidence_url: JSON.stringify(meta)
        }).eq('id', profileReq.id);

        if (mappedStatus === 'rejected' || mappedStatus === 'subscription_expired') {
          await supabase.from('profiles').update({
            is_verified: false,
            updated_at: now.toISOString()
          }).eq('user_id', profileReq.user_id);
        }
      }
    }

    // Process Organization Request
    if (orgReq) {
      let meta: any = {};
      try { meta = JSON.parse(orgReq.evidence_url || '{}'); } catch {}

      meta.didit_decision = rawDecision;
      meta.didit_status = mappedStatus;
      meta.webhook_received_at = now.toISOString();

      const isPaid = meta.payment_status === 'paid' || orgReq.status === 'verification_pending' || orgReq.status === 'approved';

      if (mappedStatus === 'approved' && isPaid) {
        await supabase.from('organization_verification_requests').update({
          status: 'approved',
          reviewed_at: now.toISOString(),
          evidence_url: JSON.stringify(meta)
        }).eq('id', orgReq.id);

        await supabase.from('organizations').update({
          verification_status: 'verified',
          verified_at: now.toISOString(),
          verified_until: validUntil,
          updated_at: now.toISOString()
        }).eq('id', orgReq.organization_id);
      } else {
        const targetReqStatus = mappedStatus === 'approved' ? 'verification_pending' : mappedStatus;
        await supabase.from('organization_verification_requests').update({
          status: targetReqStatus,
          reviewed_at: now.toISOString(),
          evidence_url: JSON.stringify(meta)
        }).eq('id', orgReq.id);

        if (mappedStatus === 'rejected' || mappedStatus === 'subscription_expired') {
          await supabase.from('organizations').update({
            verification_status: 'unverified',
            updated_at: now.toISOString()
          }).eq('id', orgReq.organization_id);
        }
      }
    }

    if (sessionId) {
      const existing = activeSessions.get(sessionId);
      if (existing) {
        existing.diditStatus = mappedStatus;
        existing.status = mappedStatus;
      }
    }

    return res.json({ success: true, mappedStatus, sessionId });
  } catch (err: any) {
    console.error('Error in Didit webhook:', err);
    return res.status(500).json({ error: err.message || 'Erro ao processar webhook' });
  }
});

// -------------------------------------------------------------
// 6. GET VERIFICATION STATUS BY REQUEST ID / SESSION ID
// Route: GET /api/verification/status/:requestId
// -------------------------------------------------------------
app.get(['/api/verification/status/:requestId', '/api/verification/session/:requestId'], async (req, res) => {
  try {
    const { requestId } = req.params;
    let cleanUuid = (requestId || '').trim().replace(/^didit_sess_/, '');
    const isValidUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cleanUuid);

    let requestData: any = null;
    let type: 'profile' | 'organization' = 'profile';

    if (isValidUuid) {
      const { data: pData } = await supabase.from('profile_verification_requests').select('*').eq('id', cleanUuid).maybeSingle();
      if (pData) {
        requestData = pData;
        type = 'profile';
      } else {
        const { data: oData } = await supabase.from('organization_verification_requests').select('*').eq('id', cleanUuid).maybeSingle();
        if (oData) {
          requestData = oData;
          type = 'organization';
        }
      }
    }

    if (!requestData) {
      const cached = activeSessions.get(requestId) || activeSessions.get(cleanUuid) || activeSessions.get(`didit_sess_${cleanUuid}`);
      if (cached) {
        return res.json({
          success: true,
          requestId: cached.requestId,
          targetType: cached.targetType,
          status: cached.status,
          paymentStatus: cached.paymentStatus,
          diditStatus: cached.diditStatus,
          verificationUrl: cached.verificationUrl,
          createdAt: cached.createdAt
        });
      }
      return res.status(404).json({ error: 'Pedido de verificação não encontrado' });
    }

    let meta: any = {};
    try { meta = JSON.parse(requestData.evidence_url || '{}'); } catch {}

    return res.json({
      success: true,
      requestId: requestData.id,
      targetType: type,
      status: requestData.status,
      paymentStatus: meta.payment_status || 'payment_pending',
      diditStatus: meta.didit_status || 'pending',
      verificationUrl: meta.verification_url,
      createdAt: requestData.created_at,
      reviewedAt: requestData.reviewed_at
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Erro ao consultar estado' });
  }
});

// -------------------------------------------------------------
// 7. SIMULATE DIDIT DECISION (ADMIN / SANDBOX EVALUATION)
// Route: POST /api/didit/simulate-decision
// -------------------------------------------------------------
app.post('/api/didit/simulate-decision', async (req, res) => {
  try {
    const { requestId, targetType, targetId, decision } = req.body;
    const now = new Date();
    const validUntil = new Date(now.getTime() + 30 * 86400000).toISOString();
    const expiredUntil = new Date(now.getTime() - 86400000).toISOString();
    const isUuid = Boolean(requestId && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(requestId));

    if (targetType === 'profile') {
      if (isUuid) {
        await supabase.from('profile_verification_requests').update({ status: decision, reviewed_at: now.toISOString() }).eq('id', requestId);
      } else if (targetId) {
        await supabase.from('profile_verification_requests').update({ status: decision, reviewed_at: now.toISOString() }).eq('user_id', targetId);
      }

      if (decision === 'approved') {
        await supabase.from('profiles').update({ is_verified: true, verified_at: now.toISOString(), verified_until: validUntil, updated_at: now.toISOString() }).eq('user_id', targetId);
      } else if (decision === 'subscription_expired') {
        await supabase.from('profiles').update({ is_verified: false, verified_until: expiredUntil, updated_at: now.toISOString() }).eq('user_id', targetId);
      } else if (['badge_suspended', 'rejected', 'not_verified'].includes(decision)) {
        await supabase.from('profiles').update({ is_verified: false, updated_at: now.toISOString() }).eq('user_id', targetId);
      }
    } else {
      if (isUuid) {
        await supabase.from('organization_verification_requests').update({ status: decision, reviewed_at: now.toISOString() }).eq('id', requestId);
      } else if (targetId) {
        await supabase.from('organization_verification_requests').update({ status: decision, reviewed_at: now.toISOString() }).eq('organization_id', targetId);
      }

      if (decision === 'approved') {
        await supabase.from('organizations').update({ verification_status: 'verified', verified_at: now.toISOString(), verified_until: validUntil, updated_at: now.toISOString() }).eq('id', targetId);
      } else if (decision === 'subscription_expired') {
        await supabase.from('organizations').update({ verification_status: 'unverified', verified_until: expiredUntil, updated_at: now.toISOString() }).eq('id', targetId);
      } else if (['badge_suspended', 'rejected', 'not_verified'].includes(decision)) {
        await supabase.from('organizations').update({ verification_status: 'unverified', updated_at: now.toISOString() }).eq('id', targetId);
      }
    }

    return res.json({ success: true, decision, targetId });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Erro na simulação' });
  }
});

// -------------------------------------------------------------
// VITE DEV / PRODUCTION SERVING
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const templatePath = path.resolve(process.cwd(), 'index.html');
        const fs = await import('fs');
        let template = fs.readFileSync(templatePath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
