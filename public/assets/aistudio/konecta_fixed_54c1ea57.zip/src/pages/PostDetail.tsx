import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Idea, CommentItem } from '../types';
import { d1Client } from '../lib/d1Client';
import { shareContent } from '../lib/share';
import { CommentCard } from '../components/CommentCard';
import { useUI } from '../context/UIContext';
import { EditPostModal } from '../components/EditPostModal';
import { Edit2, Trash2 } from 'lucide-react';

interface PostDetailProps {
  idea: Idea | any;
  user: any;
  onBack: () => void;
  onVote: (id: string) => void;
  onRequireAuth: () => void;
  onImageClick?: (url: string) => void;
}

export const PostDetail: React.FC<PostDetailProps> = ({ 
  idea, 
  user,
  onBack, 
  onVote,
  onRequireAuth,
  onImageClick
}) => {
  const { openShareSheet, showToast } = useUI();
  const [currentPost, setCurrentPost] = useState<any>(idea);
  const [showEditModal, setShowEditModal] = useState(false);

  useEffect(() => {
    setCurrentPost(idea);
  }, [idea]);

  const isOwner = user?.id === currentPost.user_id || user?.id === currentPost.author_id;

  const handleDelete = async () => {
    if (!window.confirm('Tens a certeza que desejas eliminar este item?')) return;
    try {
      if (currentPost.title !== undefined) {
        const res = await d1Client.ideas.delete(currentPost.id);
        if (res?.error) throw new Error(typeof res.error === 'string' ? res.error : res.error.message || 'Erro ao eliminar');
      } else {
        const res = await d1Client.posts.delete(currentPost.id);
        if (res?.error) throw new Error(typeof res.error === 'string' ? res.error : res.error.message || 'Erro ao eliminar');
      }
      showToast('Item eliminado com sucesso!', 'success');
      onBack();
    } catch (err: any) {
      console.error('Erro ao eliminar item:', err);
      showToast(err?.message || 'Erro ao eliminar.', 'error');
    }
  };

  const [comments, setComments] = useState<CommentItem[]>(() => {
    try {
      const cached = localStorage.getItem(`konecta_comments_${idea.id}`);
      return cached ? JSON.parse(cached) : [];
    } catch {
      return [];
    }
  });
  const [newComment, setNewComment] = useState('');
  const [loadingComments, setLoading] = useState(false);
  const [submittingComment, setSubmittingComment] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);

  // Follow State
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);

  // Bookmark / Favorite State
  const [isBookmarked, setIsBookmarked] = useState(false);

  // Report Modal State
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [submittingReport, setSubmittingReport] = useState(false);
  const [reportSuccess, setReportSuccess] = useState(false);

  // Share Modal State
  const [showShareModal, setShowShareModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    fetchComments();
    if (user && idea.user_id) {
      checkFollowStatus();
    }
  }, [idea.id, user]);

  const fetchComments = async () => {
    if (comments.length === 0) setLoading(true);
    try {
      let res = await d1Client.ideas.getComments(idea.id);
      if (!res.data?.data || res.data.data.length === 0) {
        const alt = await d1Client.posts.getComments(idea.id);
        if (alt.data?.data && alt.data.data.length > 0) {
          res = alt;
        }
      }

      if (res.data?.data && Array.isArray(res.data.data)) {
        setComments(prev => {
          const map = new Map<string, CommentItem>();
          prev.forEach(c => map.set(c.id, c));
          res.data!.data.forEach((c: CommentItem) => map.set(c.id, c));
          const merged = Array.from(map.values()).sort(
            (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          );
          try {
            localStorage.setItem(`konecta_comments_${idea.id}`, JSON.stringify(merged));
          } catch (e) {}
          return merged;
        });
      }
    } catch (err: any) {
      console.warn('Aviso ao carregar comentários:', err?.message || err);
    } finally {
      setLoading(false);
    }
  };

  const checkFollowStatus = async () => {
    if (!user || user.id === idea.user_id) return;
    try {
      const res = await d1Client.profiles.getFollowing(user.id);
      if (res.data?.data) {
        const following = res.data.data.some((f: any) => f.id === idea.user_id);
        setIsFollowing(following);
      }
    } catch (err: any) {
      console.warn('Aviso ao verificar status de seguidor:', err?.message || err);
    }
  };

  const handleToggleFollow = async () => {
    if (!user) {
      onRequireAuth();
      return;
    }
    if (user.id === idea.user_id || followLoading) return;

    setFollowLoading(true);
    const nextState = !isFollowing;
    setIsFollowing(nextState);

    try {
      await d1Client.profiles.toggleFollow(idea.user_id, !nextState);
    } catch (err: any) {
      console.warn('Aviso ao atualizar seguidor:', err?.message || err);
    } finally {
      setFollowLoading(false);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onRequireAuth();
      return;
    }
    if (!newComment.trim() || submittingComment) return;

    const contentText = newComment.trim();
    setSubmittingComment(true);

    const optimisticComment: CommentItem = {
      id: crypto.randomUUID(),
      idea_id: idea.id,
      post_id: idea.id,
      user_id: user.id,
      content: contentText,
      created_at: new Date().toISOString(),
      profiles: {
        id: user.id,
        full_name: user.user_metadata?.full_name || 'Utilizador Konecta',
        avatar_url: user.user_metadata?.avatar_url || undefined,
        province: user.user_metadata?.province || 'Angola'
      }
    };

    setComments(prev => {
      const updated = [...prev, optimisticComment];
      try {
        localStorage.setItem(`konecta_comments_${idea.id}`, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    setNewComment('');

    try {
      await d1Client.ideas.addComment(idea.id, contentText);
    } catch (err: any) {
      console.warn('Comentário guardado na cache local:', err?.message || err);
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onRequireAuth();
      return;
    }
    if (!reportReason.trim() || submittingReport) return;

    setSubmittingReport(true);
    try {
      const res = await d1Client.reports.create({
        target_type: 'idea',
        target_id: idea.id,
        reason: reportReason.trim()
      });

      if (res.error) {
        throw new Error(res.error.message || 'Erro ao submeter denúncia.');
      }

      setReportSuccess(true);
      setTimeout(() => {
        setShowReportModal(false);
        setReportSuccess(false);
        setReportReason('');
      }, 1500);
    } catch (err: any) {
      console.error('Erro ao submeter denúncia:', err);
      showToast(err?.message || 'Erro ao submeter denúncia.', 'error');
    } finally {
      setSubmittingReport(false);
    }
  };

  return (
    <div className="bg-konecta-bg min-h-screen pb-20">
      <div className="max-w-4xl mx-auto px-6 py-10 lg:py-16">
        
        {/* Back Link */}
        <button
          onClick={onBack}
          className="text-xs font-bold uppercase tracking-widest text-gray-500 hover:text-konecta-navy transition-colors flex items-center gap-2 mb-8 group"
        >
          <span className="material-symbols-outlined text-[18px] group-hover:-translate-x-1 transition-transform">arrow_back</span>
          Voltar ao feed
        </button>

        {/* Main Card */}
        <article className="card-konecta p-0 overflow-hidden mb-12 shadow-sm border border-gray-100">
          {/* Community Context Banner */}
          {idea.communities && (
            <div 
              className="h-28 relative overflow-hidden"
            >
              {idea.communities.cover_url ? (
                <img src={idea.communities.cover_url} className="w-full h-full object-cover" alt="" />
              ) : (
                <div className="w-full h-full bg-gradient-to-r from-konecta-navy to-slate-800" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-6 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-white p-0.5 border border-konecta-gold/50 shadow-lg shrink-0">
                  {idea.communities.avatar_url ? (
                    <img src={idea.communities.avatar_url} className="w-full h-full object-cover rounded-lg" alt="" />
                  ) : (
                    <div className="w-full h-full bg-konecta-navy rounded-lg flex items-center justify-center text-sm text-konecta-gold font-black">
                      {idea.communities.name.charAt(0)}
                    </div>
                  )}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-konecta-gold uppercase tracking-[0.2em] block mb-0.5">Publicado em</span>
                  <h4 className="text-sm sm:text-base font-black text-white uppercase tracking-tight">{idea.communities.name}</h4>
                </div>
              </div>
            </div>
          )}
          {idea.image_url && (
            <div 
              onClick={() => onImageClick && onImageClick(idea.image_url!)}
              className="w-full aspect-video bg-gray-100 overflow-hidden max-h-[480px] cursor-pointer group relative"
            >
              <img src={idea.image_url} alt={idea.title} className="w-full h-full object-cover group-hover:scale-[1.01] transition-transform duration-300" />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                <span className="material-symbols-outlined text-white opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 p-2.5 rounded-full backdrop-blur-xs">
                  fullscreen
                </span>
              </div>
            </div>
          )}
          
          <div className="p-8 lg:p-12">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-bold text-konecta-gold uppercase tracking-widest px-3 py-1 bg-konecta-navy/5 rounded-full border border-konecta-navy/10">
                  {idea.category}
                </span>
                <span className="metadata-text">
                  <span className="material-symbols-outlined text-[16px] text-konecta-gold">location_on</span>
                  {idea.province || 'Angola'}
                </span>
              </div>

              {/* Report button */}
              <button
                onClick={() => {
                  if (!user) onRequireAuth();
                  else setShowReportModal(true);
                }}
                className="text-xs text-gray-400 hover:text-red-500 transition-colors flex items-center gap-1 font-medium"
                title="Denunciar conteúdo impróprio"
              >
                <span className="material-symbols-outlined text-[18px]">flag</span>
                Denunciar
              </button>
            </div>

            <h1 className="text-3xl lg:text-5xl font-extrabold text-konecta-navy mb-8 leading-tight">
              {currentPost.title || currentPost.content?.substring(0, 60) || 'Publicação'}
            </h1>

            {/* Author Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-10 py-6 border-y border-gray-100">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gray-100 overflow-hidden border-2 border-white shadow-sm shrink-0">
                  {idea.profiles?.avatar_url ? (
                    <img src={idea.profiles.avatar_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center font-bold text-gray-400">
                      {idea.profiles?.full_name?.charAt(0) || 'U'}
                    </div>
                  )}
                </div>
                <div>
                  <p className="font-bold text-konecta-navy text-sm sm:text-base">{idea.profiles?.full_name || 'Membro Konecta'}</p>
                  <p className="text-xs text-gray-400">Publicado em {new Date(idea.created_at || '').toLocaleDateString('pt-AO')}</p>
                </div>
              </div>

              {isOwner ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowEditModal(true)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-gray-100 hover:bg-konecta-navy hover:text-white text-gray-700 transition-colors"
                    title="Editar publicação"
                  >
                    <Edit2 size={15} />
                    <span>Editar</span>
                  </button>
                  <button
                    onClick={handleDelete}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-red-50 hover:bg-red-500 hover:text-white text-red-600 transition-colors"
                    title="Eliminar publicação"
                  >
                    <Trash2 size={15} />
                    <span>Eliminar</span>
                  </button>
                </div>
              ) : (
                <button 
                  onClick={handleToggleFollow}
                  disabled={followLoading}
                  className={`btn-primary py-2 px-6 text-xs transition-all ${isFollowing ? 'bg-gray-100 text-gray-700 hover:bg-red-50 hover:text-red-600' : ''}`}
                >
                  {followLoading ? '...' : isFollowing ? 'A Seguir' : 'Seguir Autor'}
                </button>
              )}
            </div>

            {/* Idea / Post Content */}
            <div className="text-gray-700 leading-relaxed text-base sm:text-lg whitespace-pre-wrap mb-10">
              {currentPost.description || currentPost.content || currentPost.body || ''}
            </div>

            {/* Reaction Bar */}
            <div className="flex items-center justify-between pt-6 border-t border-gray-100">
              <div className="flex items-center gap-6">
                <button 
                  onClick={() => {
                    onVote(idea.id);
                    setHasVoted(prev => !prev);
                  }}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all duration-200 active:scale-95 shadow-xs ${
                    hasVoted 
                      ? 'bg-red-600 hover:bg-red-700 text-white border border-red-600 shadow-md shadow-red-200 scale-105' 
                      : 'bg-gray-100 hover:bg-red-50 text-gray-700 hover:text-red-600 border border-gray-200'
                  }`}
                  title={hasVoted ? 'Apoiou esta ideia' : 'Apoiar iniciativa'}
                >
                  <span 
                    className="material-symbols-outlined text-[18px] transition-transform"
                    style={hasVoted ? { fontVariationSettings: "'FILL' 1" } : undefined}
                  >
                    {hasVoted ? 'favorite' : 'favorite_border'}
                  </span>
                  <span className={hasVoted ? 'text-white font-extrabold' : ''}>{idea.votes_count || 0} Apoios</span>
                </button>
                <div className="flex items-center gap-2 text-xs font-bold text-gray-400 bg-gray-50 border border-gray-200 px-3.5 py-2 rounded-full">
                  <span className="material-symbols-outlined text-[18px]">chat_bubble_outline</span>
                  <span>{comments.length} Comentários</span>
                </div>
              </div>

              <button 
                onClick={() => {
                  openShareSheet({
                    targetId: idea.id,
                    targetType: 'idea',
                    title: idea.title,
                    authorName: idea.profiles?.full_name || 'Utilizador',
                    thumbnail: idea.image_url || undefined
                  });
                }}
                className="flex items-center gap-1.5 text-xs font-bold text-gray-500 hover:text-konecta-navy transition-colors py-1.5 px-3 rounded-lg hover:bg-gray-100"
              >
                <span className="material-symbols-outlined text-[18px]">share</span>
                Partilhar
              </button>
            </div>
          </div>
        </article>

        {/* COMMENTS SECTION */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-extrabold text-konecta-navy">
              Discussão da Comunidade ({comments.length})
            </h3>
            <span className="text-xs text-gray-400">Comentários da rede</span>
          </div>
          
          {/* Add Comment Box */}
          <form onSubmit={handleAddComment} className="card-konecta p-6 flex flex-col gap-4 shadow-sm border border-gray-100">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Partilha uma contribuição técnica, sugestão ou feedback para esta iniciativa..."
              className="w-full bg-gray-50 border-none focus:ring-1 focus:ring-konecta-navy rounded-2xl p-4 text-sm resize-none text-konecta-navy"
              rows={3}
            />
            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-400">Mantém um tom colaborativo e construtivo.</span>
              <button 
                type="submit" 
                disabled={!newComment.trim() || submittingComment} 
                className="btn-primary py-2.5 px-7 text-xs"
              >
                {submittingComment ? 'A enviar...' : 'Publicar Comentário'}
              </button>
            </div>
          </form>

          {/* Comment List */}
          <div className="space-y-4">
            {loadingComments ? (
              <div className="py-10 flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-konecta-navy"></div>
              </div>
            ) : comments.length === 0 ? (
              <div className="p-10 text-center bg-white rounded-3xl border border-dashed border-gray-200">
                <span className="material-symbols-outlined text-4xl text-gray-300 mb-2">forum</span>
                <p className="text-gray-400 italic text-sm">Ainda não existem comentários para esta iniciativa. Sê o primeiro a contribuir com sugestões.</p>
              </div>
            ) : (
              comments.map((comment) => (
                <CommentCard key={comment.id} comment={comment} />
              ))
            )}
          </div>
        </section>

      </div>

      {/* Report Modal */}
      <AnimatePresence>
        {showReportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-konecta-navy/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="text-lg font-bold text-konecta-navy">Denunciar Conteúdo</h3>
                <button onClick={() => setShowReportModal(false)} className="text-gray-400 hover:text-konecta-navy">
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              {reportSuccess ? (
                <div className="py-6 text-center text-green-600 font-bold text-sm">
                  ✓ Denúncia registada com sucesso na moderação. Obrigado pela colaboração!
                </div>
              ) : (
                <form onSubmit={handleSubmitReport} className="space-y-4">
                  <p className="text-xs text-gray-500">
                    Por favor, indica o motivo pelo qual este conteúdo viola os termos de utilização da KONECTA:
                  </p>
                  <textarea
                    required
                    rows={4}
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    placeholder="Ex: Spam, conteúdo ofensivo, dados falsos ou violação de direitos autorais..."
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm resize-none"
                  />
                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowReportModal(false)}
                      className="px-4 py-2 text-xs font-bold text-gray-500 hover:text-konecta-navy"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={submittingReport || !reportReason.trim()}
                      className="btn-primary py-2 px-5 text-xs bg-red-600 hover:bg-red-700"
                    >
                      {submittingReport ? 'A enviar...' : 'Confirmar Denúncia'}
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Share Modal */}
      <AnimatePresence>
        {showShareModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-konecta-navy/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-6"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="text-lg font-bold text-konecta-navy">Partilhar Iniciativa</h3>
                <button onClick={() => setShowShareModal(false)} className="text-gray-400 hover:text-konecta-navy">
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-gray-500">
                  Copia o link direto ou partilha esta iniciativa nas redes sociais:
                </p>

                <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-2xl p-2">
                  <input 
                    type="text" 
                    readOnly 
                    value={window.location.href} 
                    className="w-full bg-transparent text-xs text-gray-700 px-3 outline-none select-all"
                  />
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(window.location.href);
                        setCopiedLink(true);
                        setTimeout(() => setCopiedLink(false), 2000);
                      } catch (e) {}
                    }}
                    className="btn-primary py-2 px-4 text-xs font-bold shrink-0"
                  >
                    {copiedLink ? 'Copiado!' : 'Copiar'}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`Confere esta iniciativa no KONECTA: ${idea.title} - ${window.location.href}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white rounded-2xl py-3 text-xs font-bold transition-all shadow-sm"
                  >
                    <span className="material-symbols-outlined text-[18px]">chat</span>
                    WhatsApp
                  </a>
                  <a
                    href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white rounded-2xl py-3 text-xs font-bold transition-all shadow-sm"
                  >
                    <span className="material-symbols-outlined text-[18px]">work</span>
                    LinkedIn
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      {showEditModal && (
        <EditPostModal
          post={currentPost}
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          onSaved={(updated) => setCurrentPost(updated)}
        />
      )}

    </div>
  );
};
